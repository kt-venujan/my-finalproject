"use client";

import { useEffect, useState } from "react";
import api from "@/lib/axios";

export default function AdminDashboard() {
  const [foods, setFoods] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [image, setImage] = useState("");

  const [catName, setCatName] = useState("");
  const [catImage, setCatImage] = useState("");

  // ================= FETCH =================
  const fetchFoods = async () => {
    try {
      const res = await api.get("/foods");
      setFoods(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await api.get("/categories");
      setCategories(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchFoods();
    fetchCategories();
  }, []);

  // ================= ADD FOOD =================
  const addFood = async () => {
    if (!name || !price || !category || !image) {
      alert("Fill all fields");
      return;
    }

    try {
      await api.post("/admin/foods", {
        name,
        price: Number(price),
        category,
        image,
      });

      setName("");
      setPrice("");
      setCategory("");
      setImage("");

      fetchFoods();
    } catch (err) {
      console.error(err);
    }
  };

  // ================= DELETE FOOD =================
  const deleteFood = async (id: string) => {
    try {
      await api.delete(`/foods/${id}`);
      fetchFoods();
    } catch (err) {
      console.error(err);
    }
  };

  // ================= ADD CATEGORY =================
  const addCategory = async () => {
    if (!catName) {
      alert("Enter category name");
      return;
    }

    try {
      await api.post("/categories", {
        name: catName,
        image: catImage || "",
      });

      setCatName("");
      setCatImage("");

      fetchCategories();
    } catch (err) {
      console.error(err);
    }
  };

  // ================= DELETE CATEGORY =================
  const deleteCategory = async (id: string) => {
    try {
      await api.delete(`/categories/${id}`);
      fetchCategories();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="admin-page">
      <h1 className="admin-title">Admin Dashboard 🔥</h1>

      {/* CATEGORY ADD */}
      <div className="card">
        <h2>Add Category</h2>

        <input
          placeholder="Category Name"
          value={catName}
          onChange={(e) => setCatName(e.target.value)}
        />

        <input
          placeholder="/uploads/oats.jpg"
          value={catImage}
          onChange={(e) => setCatImage(e.target.value)}
        />

        <button onClick={addCategory}>Add Category</button>
      </div>

      {/* CATEGORY LIST */}
      <div className="food-grid">
        {categories.map((c) => (
          <div className="food-card" key={c._id}>
            <img
              src={
                c.image
                  ? `http://localhost:5000${c.image}`
                  : "http://localhost:5000/uploads/pizza.jpg"
              }
              style={{
                width: "100%",
                height: "120px",
                objectFit: "cover",
              }}
            />

            <h3>{c.name}</h3>

            <button
              style={{
                marginTop: "10px",
                background: "crimson",
                color: "white",
                border: "none",
                padding: "6px",
                borderRadius: "6px",
              }}
              onClick={() => deleteCategory(c._id)}
            >
              Delete Category
            </button>
          </div>
        ))}
      </div>

      {/* FOOD ADD */}
      <div className="card">
        <h2>Add Food</h2>

        <input
          placeholder="Food Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">Select Category</option>
          {categories.map((c) => (
            <option key={c._id} value={c.name}>
              {c.name}
            </option>
          ))}
        </select>

        <input
          placeholder="/uploads/pizza.jpg"
          value={image}
          onChange={(e) => setImage(e.target.value)}
        />

        <button onClick={addFood}>Add Food</button>
      </div>

      {/* FOOD LIST */}
      <div className="food-grid">
        {foods.map((f) => (
          <div className="food-card" key={f._id}>
            <img
              src={`http://localhost:5000${f.image}`}
              style={{
                width: "100%",
                height: "150px",
                objectFit: "cover",
              }}
            />

            <h3>{f.name}</h3>
            <p>Rs. {f.price}</p>
            <span>{f.category}</span>

            <button
              style={{
                marginTop: "10px",
                background: "#8b0c2e",
                color: "white",
                border: "none",
                padding: "6px",
                borderRadius: "6px",
              }}
              onClick={() => deleteFood(f._id)}
            >
              Delete Food
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}